"""Owner-instruction authority journal and fail-closed contradiction gate.

Raw owner directives are append-only and evaluated locally with a pinned ONNX
natural-language-inference model.  Lower-authority mutations that contradict
a newer explicit owner directive are rejected and logged before persistence.
No journal text is sent to a remote model.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import threading
from typing import Iterable, Optional

_AUTHORITY_DIR = Path(os.getenv("MNEMOSYNE_AUTHORITY_DIR", "/opt/data/authority"))
_DIRECTIVES = _AUTHORITY_DIR / "owner-directives.jsonl"
_DECISIONS = _AUTHORITY_DIR / "write-decisions.jsonl"
_MODEL_DIR = Path(os.getenv(
    "MNEMOSYNE_AUTHORITY_MODEL_DIR",
    "/opt/data/mnemosyne/models/nli-deberta-v3-small",
))
_MODEL_FILE = _MODEL_DIR / "onnx" / "model_quint8_avx2.onnx"
_TOKENIZER_FILE = _MODEL_DIR / "tokenizer.json"

# Avoid writing likely credentials to the journal.  Ambiguous messages are
# skipped rather than redacted into a misleading directive.
_SECRET_PATTERNS = (
    re.compile(r"(?i)\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|secret)\b\s*[:=]"),
    re.compile(r"\b(?:sk|ghp|github_pat|xox[baprs]|hf)_[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\b[A-Za-z0-9+/]{40,}={0,2}\b"),
)
_DIRECTIVE_CUES = re.compile(
    r"(?i)(?:\bdo not\b|\bdon['’]t\b|\bnever\b|\balways\b|\bmust\b|"
    r"\bstop\b|\buse\b|\bkeep\b|\bmake sure\b|\bI (?:want|prefer|told|said|asked)\b|"
    r"\bexplicit instruction\b|\bget back to work\b|\bwrap it up\b)"
)
_TOKEN_RE = re.compile(r"[A-Za-z0-9_'-]+")
_STOP = {
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "for", "from",
    "here", "i", "in", "is", "it", "just", "me", "my", "of", "on", "or", "that",
    "the", "then", "there", "this", "to", "was", "we", "when", "with", "you", "your",
}

_LOCK = threading.RLock()
_RUNTIME = None
_RUNTIME_ERROR: Optional[str] = None


@dataclass(frozen=True)
class AuthorityDecision:
    allowed: bool
    reason: str
    operation: str
    source: str
    directive_id: str | None = None
    directive: str | None = None
    contradiction: float = 0.0
    entailment: float = 0.0
    neutral: float = 0.0
    fail_closed: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


class AuthorityRejectedError(RuntimeError):
    """Raised before persistence when a lower-authority write is rejected."""

    def __init__(self, decision: AuthorityDecision):
        self.decision = decision
        super().__init__(
            f"{decision.operation} rejected by explicit owner authority: "
            f"{decision.reason}"
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
    # O_APPEND makes each short record one atomic append on local filesystems.
    with _LOCK:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, line.encode("utf-8"))
            os.fsync(fd)
        finally:
            os.close(fd)


def _clean_owner_text(text: object) -> str:
    if not isinstance(text, str):
        return ""
    # Runtime-injected recall blocks are context, not a fresh owner statement.
    text = re.sub(r"(?is)<memory-context>.*?</memory-context>", "", text)
    text = re.sub(r"(?is)\[CONTEXT COMPACTION.*?--- END OF CONTEXT SUMMARY.*?---", "", text)
    return re.sub(r"\s+", " ", text).strip()


def contains_likely_secret(text: str) -> bool:
    return any(p.search(text) for p in _SECRET_PATTERNS)


def looks_like_directive(text: str) -> bool:
    return bool(text and _DIRECTIVE_CUES.search(text))


def record_owner_directive(
    text: object,
    *,
    platform: str,
    user_id: str,
    session_id: str = "",
    turn_id: str = "",
    timestamp: Optional[str] = None,
) -> dict:
    """Append one exact owner directive, or return a structured skip result."""
    clean = _clean_owner_text(text)
    if not clean or not looks_like_directive(clean):
        return {"recorded": False, "reason": "not_directive"}
    if contains_likely_secret(clean):
        _append_jsonl(_DECISIONS, {
            "at": _utc_now(), "allowed": False, "event": "directive_skipped",
            "reason": "likely_secret", "platform": platform, "turn_id": turn_id,
        })
        return {"recorded": False, "reason": "likely_secret"}
    directive_id = hashlib.sha256(
        f"{platform}\0{user_id}\0{turn_id}\0{clean}".encode("utf-8")
    ).hexdigest()[:24]
    record = {
        "id": directive_id,
        "at": timestamp or _utc_now(),
        "authority": "explicit_owner",
        "platform": str(platform),
        "user_id": str(user_id),
        "session_id": str(session_id or ""),
        "turn_id": str(turn_id or ""),
        "text": clean,
    }
    # Idempotence for turn retries: a duplicate ID is harmless but unnecessary.
    if any(row.get("id") == directive_id for row in load_directives(limit=64)):
        return {"recorded": False, "reason": "duplicate", "id": directive_id}
    _append_jsonl(_DIRECTIVES, record)
    return {"recorded": True, "id": directive_id}


def load_directives(*, limit: int = 256) -> list[dict]:
    if not _DIRECTIVES.exists():
        return []
    try:
        lines = _DIRECTIVES.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    rows: list[dict] = []
    for line in reversed(lines[-max(limit * 2, limit):]):
        try:
            row = json.loads(line)
        except Exception:
            continue
        if row.get("authority") == "explicit_owner" and row.get("text"):
            rows.append(row)
            if len(rows) >= limit:
                break
    return rows


def _tokens(text: str) -> set[str]:
    return {t.lower() for t in _TOKEN_RE.findall(text) if len(t) > 1 and t.lower() not in _STOP}


def _related(a: str, b: str) -> bool:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return False
    shared = ta & tb
    if not shared:
        return False
    # One distinctive shared token is enough for short directives; longer text
    # requires either two shared tokens or 12% overlap with the directive.
    distinctive = {t for t in shared if len(t) >= 5}
    return bool(distinctive) or len(shared) >= 2 or len(shared) / max(1, len(ta)) >= 0.12


def _runtime():
    global _RUNTIME, _RUNTIME_ERROR
    if _RUNTIME is not None:
        return _RUNTIME
    if _RUNTIME_ERROR is not None:
        raise RuntimeError(_RUNTIME_ERROR)
    try:
        import numpy as np
        import onnxruntime as ort
        from tokenizers import Tokenizer
        tok = Tokenizer.from_file(str(_TOKENIZER_FILE))
        sess = ort.InferenceSession(str(_MODEL_FILE), providers=["CPUExecutionProvider"])
        _RUNTIME = (tok, sess, np)
        return _RUNTIME
    except Exception as exc:
        _RUNTIME_ERROR = f"local authority model unavailable: {type(exc).__name__}: {exc}"
        raise RuntimeError(_RUNTIME_ERROR) from exc


def nli_scores(premise: str, hypothesis: str) -> tuple[float, float, float]:
    tok, sess, np = _runtime()
    encoded = tok.encode(premise, hypothesis)
    # Bound runtime cost and preserve pair terminators.
    if len(encoded.ids) > 256:
        encoded.truncate(256)
    arrays = {
        "input_ids": np.array([encoded.ids], dtype=np.int64),
        "attention_mask": np.array([encoded.attention_mask], dtype=np.int64),
        "token_type_ids": np.array([encoded.type_ids], dtype=np.int64),
    }
    inputs = {item.name: arrays[item.name] for item in sess.get_inputs() if item.name in arrays}
    logits = sess.run(None, inputs)[0][0]
    exp = np.exp(logits - logits.max())
    probs = exp / exp.sum()
    return float(probs[0]), float(probs[1]), float(probs[2])


def _candidate_chunks(candidate: str) -> list[str]:
    clean = re.sub(r"\s+", " ", candidate).strip()
    if len(clean) <= 900:
        return [clean]
    # Full skill/canonical payloads can be large. Keep clauses local so a buried
    # contradiction is not truncated out by the 256-token NLI input limit.
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+|\n+", candidate) if p.strip()]
    chunks: list[str] = []
    current = ""
    for part in parts:
        if len(current) + len(part) + 1 > 700 and current:
            chunks.append(current)
            current = part
        else:
            current = f"{current} {part}".strip()
    if current:
        chunks.append(current)
    return chunks[:80]


def check_lower_authority_write(
    candidate: object,
    *,
    operation: str,
    source: str,
    directives: Optional[Iterable[dict]] = None,
    contradiction_threshold: float = 0.85,
    entailment_threshold: float = 0.80,
) -> AuthorityDecision:
    """Reject a lower-authority candidate that contradicts the newest relevant owner directive.

    Newest relevant owner statement wins.  If local NLI is unavailable, writes
    with lexical overlap fail closed; unrelated writes remain usable.
    """
    text = str(candidate or "").strip()
    if not text:
        return AuthorityDecision(True, "empty_or_noncontent_write", operation, source)
    rows = list(directives) if directives is not None else load_directives()
    if not rows:
        return AuthorityDecision(True, "no_owner_directives", operation, source)
    chunks = _candidate_chunks(text)
    for row in rows:  # journal loader is newest first
        directive = str(row.get("text") or "").strip()
        related_chunks = [chunk for chunk in chunks if _related(directive, chunk)]
        if not related_chunks:
            continue
        best_entail = 0.0
        best_neutral = 0.0
        try:
            for chunk in related_chunks:
                contradiction, entailment, neutral = nli_scores(directive, chunk)
                best_entail = max(best_entail, entailment)
                best_neutral = max(best_neutral, neutral)
                if contradiction >= contradiction_threshold:
                    decision = AuthorityDecision(
                        False, "contradicts_explicit_owner_directive", operation, source,
                        str(row.get("id") or ""), directive,
                        contradiction, entailment, neutral, False,
                    )
                    _append_jsonl(_DECISIONS, {"at": _utc_now(), **asdict(decision)})
                    return decision
            # A clear entailment to the newest relevant directive settles this
            # subject and prevents an older superseded instruction from winning.
            if best_entail >= entailment_threshold:
                return AuthorityDecision(
                    True, "entailed_by_newest_relevant_owner_directive", operation, source,
                    str(row.get("id") or ""), directive,
                    0.0, best_entail, best_neutral, False,
                )
        except Exception as exc:
            decision = AuthorityDecision(
                False, f"authority_model_failure:{type(exc).__name__}", operation, source,
                str(row.get("id") or ""), directive,
                0.0, 0.0, 0.0, True,
            )
            _append_jsonl(_DECISIONS, {"at": _utc_now(), **asdict(decision)})
            return decision
    return AuthorityDecision(True, "no_contradiction_found", operation, source)


def check_lower_authority_removal(
    existing_content: object,
    *,
    operation: str,
    source: str,
    directives: Optional[Iterable[dict]] = None,
    contradiction_threshold: float = 0.85,
    entailment_threshold: float = 0.80,
) -> AuthorityDecision:
    """Protect owner-aligned material from lower-authority deletion/invalidation."""
    text = str(existing_content or "").strip()
    if not text:
        return AuthorityDecision(True, "empty_or_missing_removal_target", operation, source)
    rows = list(directives) if directives is not None else load_directives()
    chunks = _candidate_chunks(text)
    for row in rows:
        directive = str(row.get("text") or "").strip()
        related_chunks = [chunk for chunk in chunks if _related(directive, chunk)]
        if not related_chunks:
            continue
        try:
            scores = [nli_scores(directive, chunk) for chunk in related_chunks]
            best_entail = max(score[1] for score in scores)
            best_contradiction = max(score[0] for score in scores)
            best_neutral = max(score[2] for score in scores)
            if best_entail >= entailment_threshold:
                decision = AuthorityDecision(
                    False, "would_remove_owner_aligned_material", operation, source,
                    str(row.get("id") or ""), directive,
                    best_contradiction, best_entail, best_neutral, False,
                )
                _append_jsonl(_DECISIONS, {"at": _utc_now(), **asdict(decision)})
                return decision
            if best_contradiction >= contradiction_threshold:
                return AuthorityDecision(
                    True, "removes_contradictory_lower_authority_material", operation, source,
                    str(row.get("id") or ""), directive,
                    best_contradiction, best_entail, best_neutral, False,
                )
            decision = AuthorityDecision(
                False, "ambiguous_relevant_removal", operation, source,
                str(row.get("id") or ""), directive,
                best_contradiction, best_entail, best_neutral, True,
            )
            _append_jsonl(_DECISIONS, {"at": _utc_now(), **asdict(decision)})
            return decision
        except Exception as exc:
            decision = AuthorityDecision(
                False, f"authority_model_failure:{type(exc).__name__}", operation, source,
                str(row.get("id") or ""), directive,
                0.0, 0.0, 0.0, True,
            )
            _append_jsonl(_DECISIONS, {"at": _utc_now(), **asdict(decision)})
            return decision
    return AuthorityDecision(True, "no_related_owner_directive", operation, source)


def enforce_lower_authority_removal(
    existing_content: object,
    *,
    operation: str,
    source: str,
) -> AuthorityDecision:
    decision = check_lower_authority_removal(
        existing_content,
        operation=operation,
        source=source,
    )
    if not decision.allowed:
        raise AuthorityRejectedError(decision)
    return decision


def decision_payload(decision: AuthorityDecision) -> dict:
    return asdict(decision)


def enforce_lower_authority_write(
    candidate: object,
    *,
    operation: str,
    source: str,
) -> AuthorityDecision:
    """Return an allow decision or raise before any lower-authority mutation."""
    decision = check_lower_authority_write(
        candidate,
        operation=operation,
        source=source,
    )
    if not decision.allowed:
        raise AuthorityRejectedError(decision)
    return decision
