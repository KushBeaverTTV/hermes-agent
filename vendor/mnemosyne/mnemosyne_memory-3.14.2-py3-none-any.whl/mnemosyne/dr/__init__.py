"""Mnemosyne Disaster Recovery Module"""
